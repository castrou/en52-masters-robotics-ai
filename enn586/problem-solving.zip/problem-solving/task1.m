clear;
close all;

rng(42);

%% Set up
C = [1.3, 5].';
R = 10;

k_count = 100;

%% 1.1 Data Generation
y = noisy_meas_seq(k_count, C, R);
C_plot = ones([k_count 2]) .* C.';

% measurement plot
figure Name Measurement

subplot(2,1,1)
plot(y(:, 1))
ylabel('x_{val}');
hold on
plot(C_plot(:,1))
title('Measurement')

subplot(2,1,2)
plot(y(:, 2))
ylabel('y_{val}');
hold on
plot(C_plot(:,2))
xlabel('Step');


%% 1.2 Recursive Estimation
C_1 = [0.5, 1];
C_hat = estimate_seq(k_count, y, C_1);

% estimation plot
figure Name Estimation
subplot(2,1,1)
plot(C_hat(:, 1))
ylabel('x_{val}');
hold on
plot(C_plot(:,1))
title('Estimation')

subplot(2,1,2)
plot(C_hat(:, 2))
ylabel('y_{val}');
hold on
plot(C_plot(:,2))
xlabel('Step');

% error
err_sq = (C_hat - C_plot) .^ 2;
rms = sqrt(1/k_count * sum(err_sq))
% error plot
figure Name Error
title('Error')
subplot(1,2,1)
plot(err_sq(:,1))
title('X Error v Time Step')
subplot(1,2,2)
plot(err_sq(:,2))
title('Y Error v Time Step')

%% 1.3 Parametric Study
% Base Case: R value = 10, C1 = [0.5, 1]'
R_vals = [0.1, 1, 10, 100];
C1_vals = [0.5, 1; 
           1.3, 5;
           100, 100;];

% set up parametric cases
P1.R = R_vals(1);
P1.C1 = C1_vals(1,:);
P1.y = zeros([k_count 2]);
P1.C_hat = zeros([k_count 2]);
P1.err_sq = zeros([k_count 2]);
P1.rms = zeros([2 1]);
P = [P1,P1,P1,P1,P1,P1,P1,P1,P1,P1,P1,P1];
i = 1;
for R = R_vals
    for C1 = C1_vals'
        P(i).R = R;
        P(i).C1 = C1;
        i = i + 1;
    end
end

for i = 1:size(P, 2)
    R = P(i).R;
    C1 = P(i).C1;
    P(i).y = noisy_meas_seq(k_count,C,R);
    P(i).C_hat = estimate_seq(k_count, P(i).y, C1);
    P(i).err_sq = (P(i).C_hat - C_plot) .^ 2;
    rms = sqrt(1/k_count * sum(P(i).err_sq));
    P(i).rms = rms';
end

%% Function Definitions
%% %% Data Generation
function y_k = noisy_meas_step(C, covar)
    w_k = covar * randn([2 1]);
    y_k = C + w_k;
end

function y = noisy_meas_seq(k, C, R)
    covar = (sqrt(R) * eye(2)); % this is the step I messed up with the other tasks
    y = zeros([k 2]);
    for k = 1:k
        y(k, :) = noisy_meas_step(C, covar).';
    end
end

%% %% Recursive Estimation
function C_hat_k = estimate_step(k, C_hat_prev, y_k)
    inv_k = 1/k;
    C_hat_k = (k-1)*inv_k*C_hat_prev + inv_k*y_k;
end

function C_hat = estimate_seq(T, y_seq, C_1)
    C_hat = zeros([T 2]);
    C_hat(1, :) = C_1;
    for k = 2:T
        C_hat(k, :) = estimate_step(k, C_hat(k-1,:), y_seq(k,:));
    end
end

%% %% Plot
function err_ = plot_err(err_sq)
    figure Name Error
    title('Error')
    subplot(1,2,1)
    plot(err_sq(:,1))
    title('X Error v Time Step')
    subplot(1,2,2)
    plot(err_sq(:,2))
    title('Y Error v Time Step')
end