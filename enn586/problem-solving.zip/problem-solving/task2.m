clear;
close all;

rng(42);

%% init
T = 1000; % no. time instants
dT = 1;

A = [1, 0, dT, 0;
     0, 1, 0, dT;
     0, 0, 1, 0;
     0, 0, 0, 1];

sig_x = 0;
sig_y = 0;
sig_dx = 0.01;
sig_dy = 0.01;
R = 10 * eye(2);
Q = [sig_x, 0, 0, 0;
     0, sig_y, 0, 0;
     0, 0, sig_dx, 0;
     0, 0, 0, sig_dy;];
H = [eye(2), zeros(2)];

x_0 = [10000, 10000, 1, 0];
y_0 = x_0(:, 1:2);

x_hat = zeros(T, 4);
x_hat(1, :) = x_0 + [100, 100, 0.1, -0.1];

P = 1000 * eye(4);
P_next = P;

%% Model mismatches
delta_A = A * 0.1;
delta_H = H * 0.1;
delta_Q = Q;
delta_R = R;
A_kalman = A + delta_A; 
H_kalman = H + delta_H;  
Q_true = Q + delta_Q;
R_true = R + delta_R;

%% 2.1 Data Generation
[x, y] = measurement_sequence(T, x_0, y_0, A, H, Q, R);
noise = x(:, 1:2)-y; % not particularly useful, though confirmed random noise was okay

figure Name '2.1 Data Gen'
subplot(2, 2, 1);
plot(x(:,1), x(:,2));
title("Raw Position (x^c vs y^c)");

subplot(2, 2, 2);
plot(y(:,1), y(:,2));
title("Measured Position (x^{gps} vs y^{gps})");

subplot(2, 2, 3);
plot(1:T, x(:,1), 1:T, y(:,1));
title("x^c and x^{gps} vs k");
legend('True','Measured')

subplot(2, 2, 4);
plot(1:T, x(:,2), 1:T, y(:,2));
title("y^c and y^{gps} vs k");
legend('True','Measured')

%% 2.2 Kalman Filter
P_diag = ones([T 4]);
P_diag(1,:) = (P_next * ones([4 1]))';
K_vals = ones([T 4]);

for k = 2:T
    P_prev = P_next;
    [x_pred, P_pred] = kalman_predict(A, x_hat(k-1, :), P_prev, Q);
    z_k = y(k, :);
    [x_hat(k, :), P_next, K] = kalman_measure(x_pred, P_pred, z_k, H, R);
    P_diag(k,:) = (P_next * ones([4 1]))';
    K_vals(k,:) = K(K ~= 0);
end

% plotting
figure Name '2.2 Kalman Filter';
subplot(2,1,1);
plot(1:T,x(:,1),1:T,x_hat(:,1),1:T,y(:,1));
legend('True','KF Estimate','Measured')
ylabel('x');
title('x^c, x^{hat}, x^{gps} vs k')
subplot(2,1,2);
plot(1:T,x(:,2),1:T,x_hat(:,2),1:T,y(:,2));
ylabel('y');
title('y^c, y^{hat}, y^{gps} vs k')

err_sq = (x_hat - x).^2;
rms = sqrt(1/T * sum(err_sq))

% error and covariance
figure Name '2.2 Error and Covariance';
subplot(2,2,1)
plot(1:T,err_sq(:,1),1:T,P_diag(:,1));
xlim([-100 1000])
ylim([-1000 11000]);
legend('Squared Error','Error Covariance')
title('x^c sq-err vs err-covar')
subplot(2,2,2)
plot(1:T,err_sq(:,2),1:T,P_diag(:,2));
xlim([-100 1000])
ylim([-1000 11000]);
legend('Squared Error','Error Covariance')
title('y^c sq-err vs err-covar')
subplot(2,2,3)
plot(1:T,err_sq(:,3),1:T,P_diag(:,3));
xlim([-100 1000])
ylim([-1000 3000]);
legend('Squared Error','Error Covariance')
title('dx^c sq-err vs err-covar')
subplot(2,2,4)
plot(1:T,err_sq(:,4),1:T,P_diag(:,4));
xlim([-100 1000])
ylim([-1000 3000]);
legend('Squared Error','Error Covariance')
title('dy^c sq-err vs err-covar')

% k plot
figure Name '2.2 K Plot';
subplot(2,2,1)
plot(1:T,K_vals(:,1));
title('K (1,1)')
subplot(2,2,2)
plot(1:T,K_vals(:,2));
title('K (2,2)')
subplot(2,2,3)
plot(1:T,K_vals(:,3));
title('K (3,1)')
subplot(2,2,4)
plot(1:T,K_vals(:,4));
title('K (4,2)')

%% 2.3 Parametric Study
study_default.P = P_diag(1000,:);
study_default.K = K_vals(1000,:);
study_default.rms = rms;

%% %% R variation
% R=1
R_param = 1 * eye(2);
[P_diag, K_seq, rms] = param_study_instance(R_param, Q, P);
R1_study.P = P_diag(1000,:);
R1_study.K = K_seq(1000,:);
R1_study.rms = rms;
% R=100
R_param = 100 * eye(2);
[P_diag, K_seq, rms] = param_study_instance(R_param, Q, P);
R100_study.P = P_diag(1000,:);
R100_study.K = K_seq(1000,:);
R100_study.rms = rms;
% R=1000
R_param = 1000 * eye(2);
[P_diag, K_seq, rms] = param_study_instance(R_param, Q, P);
R1000_study.P = P_diag(1000,:);
R1000_study.K = K_seq(1000,:);
R1000_study.rms = rms;

%% %% Q Variation
% sigma dx&dy = 0.001
Q_param = Q / 10;
[P_diag, K_seq, rms] = param_study_instance(R, Q_param, P);
Q0001_study.P = P_diag(1000,:);
Q0001_study.K = K_seq(1000,:);
Q0001_study.rms = rms;
% sigma dx&dy = 0.1
Q_param = Q * 10;
[P_diag, K_seq, rms] = param_study_instance(R, Q_param, P);
Q01_study.P = P_diag(1000,:);
Q01_study.K = K_seq(1000,:);
Q01_study.rms = rms;
% sigma dx&dy = 1
Q_param = Q * 100;
[P_diag, K_seq, rms] = param_study_instance(R, Q_param, P);
Q1_study.P = P_diag(1000,:);
Q1_study.K = K_seq(1000,:);
Q1_study.rms = rms;

%% %% P Variation
% P = 10I
P_param = P / 100;
[P_diag, K_seq, rms] = param_study_instance(R, Q, P_param);
P10_study.P = P_diag(1000,:);
P10_study.K = K_seq(1000,:);
P10_study.rms = rms;
% P = 100I
P_param = P / 10;
[P_diag, K_seq, rms] = param_study_instance(R, Q, P_param);
P100_study.P = P_diag(1000,:);
P100_study.K = K_seq(1000,:);
P100_study.rms = rms;
% P = 10000I
P_param = P * 10;
[P_diag, K_seq, rms] = param_study_instance(R, Q, P_param);
P10k_study.P = P_diag(1000,:);
P10k_study.K = K_seq(1000,:);
P10k_study.rms = rms;

%% Function Definitions
%% Data Generation
function [x_truth, y_meas] = measurement_sequence(len, x_0, y_0, A, H, Q, R)
    x_truth = zeros([len 4]);
    y_meas = zeros([len 2]);
    
    x_truth(1, :) = x_0;
    y_meas(1, :) = y_0;
    for k = 2:len
        x_truth(k, :) = A * x_truth(k-1, :)' + sqrt(Q)*randn([4 1]);
        y_meas(k, :) = H * x_truth(k, :)' + sqrt(R)*randn([2 1]);
    end
end

%% Kalman Time Update
function [x_pred, P_pred] = kalman_predict(A_prev, x_prev, P_prev, Q_prev)
    x_pred = (A_prev*x_prev')';
    P_pred = A_prev*P_prev*A_prev' + Q_prev;
end

%% Kalman Meas Update
function [x_est, P, K] = kalman_measure(x_pred, P_pred, z, H, R)
    K = P_pred*H'*inv(H*P_pred*H'+R);
    x_est = x_pred + (K*(z'-H*x_pred'))';
    P = (eye(4) - K*H)*P_pred;
end

%% Kalman Full Sequence
function [P_diag, K_seq, rms] = param_study_instance(R, Q, P)
    % init
    T = 1000; % no. time instants
    dT = 1;
    A = [1, 0, dT, 0;
         0, 1, 0, dT;
         0, 0, 1, 0;
         0, 0, 0, 1];
    H = [eye(2), zeros(2)];
    x_0 = [10000, 10000, 1, 0];
    y_0 = x_0(:, 1:2);
    x_hat = zeros(T, 4);
    x_hat(1, :) = x_0 + [100, 100, 0.1, -0.1];
    % data gen
    [x, y] = measurement_sequence(T, x_0, y_0, A, H, Q, R);
    % kf
    P_next = P;
    P_diag = ones([T 4]);
    P_diag(1,:) = (P_next * ones([4 1]))';
    K_seq = ones([T 4]);
    for k = 2:T
        P_prev = P_next;
        [x_pred, P_pred] = kalman_predict(A, x_hat(k-1, :), P_prev, Q);
        z_k = y(k,:);
        [x_hat(k,:), P_next, K] = kalman_measure(x_pred, P_pred, z_k, H, R);
        P_diag(k,:) = (P_next * ones([4 1]))';
        K_seq(k,:) = K(K ~= 0);
    end
    % err
    err_sq = (x_hat - x).^2;
    rms = sqrt(1/T * sum(err_sq));
end