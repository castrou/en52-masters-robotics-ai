function m= get_map()
    global map
    m = map;