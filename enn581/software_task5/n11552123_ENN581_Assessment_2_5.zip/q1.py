from task5 import *


if __name__ == '__main__':
    robot_trajectory = simulate_robot(1)
    plot_traj(robot_trajectory)