import argparse
import configparser
import os
import sys
import json 
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt
import cv2
import open3d as o3d

import ipywidgets as widgets
from ipywidgets import interact, interact_manual, interactive
from IPython.display import display

from matplotlib import pyplot as plt

from glob import glob
from PIL import Image

import spatialmath as sm


def run():
    basepath = Path().absolute() # Get this notebooks path
    trajectory_1_path = (basepath / "trajectory_1")
    trajectory_2_path = (basepath / "trajectory_2")

    # load the json file for trajectory 1
    with open(trajectory_1_path / "trajectory_1.json") as f:
        traj1 = json.load(f)

    # load the json file for trajectory 2
    with open(trajectory_2_path / "trajectory_2.json") as f:
        traj2 = json.load(f)

    traj1_img_fn = [(trajectory_1_path / frame['file_path']) for frame in traj1["frames"]]
    imgs_db = [np.array(Image.open(fn)) for fn in traj1_img_fn]
    depth_db = [np.array(Image.open((trajectory_1_path / frame['depth_path']))) for frame in traj1['frames']]

    traj2_img_fn = [(trajectory_2_path / frame['file_path']) for frame in traj2["frames"]]
    imgs_q = [np.array(Image.open(fn)) for fn in traj2_img_fn]
    depth_q = [np.array(Image.open((trajectory_2_path / frame['depth_path']))) for frame in traj2['frames']]
    
    # Initialize camera parameters
    fx = traj1['fl_x'] # Focal length in pixels
    fy = traj1['fl_y']
    cx = traj1['cx']  # Principal point in pixels
    cy = traj1['cy']
    K = np.array([[fx, 0, cx], [0, fy, cy], [0, 0, 1]])
    
    rgbd_db = []
    for frame in traj1['frames']:
        img_path = str((trajectory_1_path / frame['file_path']))
        depth_path = str((trajectory_1_path / frame['depth_path']))
        color_raw = o3d.io.read_image(img_path)
        depth_raw = o3d.io.read_image(depth_path)
        rgbd_image = o3d.geometry.RGBDImage.create_from_color_and_depth(
        color_raw, depth_raw, depth_scale=10000, depth_trunc=6)
        rgbd_db.append(rgbd_image)
        
    camera_intrinsic = o3d.camera.PinholeCameraIntrinsic(1920, 1440, K)
    pcd = o3d.geometry.PointCloud.create_from_rgbd_image(rgbd_image, camera_intrinsic)
    # Flip it, otherwise the pointcloud will be upside down
    pcd.transform([[1, 0, 0, 0], [0, -1, 0, 0], [0, 0, -1, 0], [0, 0, 0, 1]])
    o3d.visualization.draw_geometries([pcd])

if __name__ == '__main__':
    run()